package com.cg.feedback.course.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.feedback.course.dao.CourseDAO;
import com.cg.feedback.course.dto.CourseDTO;
import com.cg.feedback.course.exceptions.CustomException;

@Service
public class CourseServiceImpl implements CourseService {
	
	@Autowired
	CourseDAO courseDao;

	@Override
	public List<CourseDTO> getAllCourses() {
		return courseDao.findAll();
	}

	@Override
	public Optional<CourseDTO> getCourseById(String courseId) {
		if(courseDao.existsById(courseId))
			return courseDao.findById(courseId);
		else
			throw new CustomException("Course with id :"+courseId+" not found");
			
	}

	@Override
	public boolean removeCourse(String courseId) {
		if(courseDao.existsById(courseId))
		{
			courseDao.deleteById(courseId);
			return true;
		}
		else
			throw new CustomException("Course with id :"+courseId+" not found");
	}

	@Override
	public CourseDTO addCourse(CourseDTO course) {
		if(!courseDao.existsById(course.getCourseId()))
			return courseDao.save(course);
		else
			throw new CustomException("Course with Id:"+ course.getCourseId()+"already present.");
	}

}
