package com.cg.feedback.program.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cg.feedback.program.dto.ProgramDTO;
import com.cg.feedback.program.services.ProgramService;

@RestController
public class ProgramServiceController {
	@Autowired
	ProgramService programService;
	

	@GetMapping(value="/all/programs/")
	public ResponseEntity<List<ProgramDTO>> getAllprograms()
	{
		List<ProgramDTO> programs=programService.getAllPrograms();
		return new ResponseEntity<List<ProgramDTO>>(programs, HttpStatus.OK);
	}
	
	
	@GetMapping(value="/all/programs/{programId}")
	public ResponseEntity<ProgramDTO> getprogramById(@PathVariable("programId") String programId)
	{
		ProgramDTO program =programService.getProgramById(programId).get();
		return new ResponseEntity<ProgramDTO>(program,HttpStatus.OK);
	}
	
	
	@DeleteMapping(value="/admin/programs/")
	public ResponseEntity<String> delteprogramById(@RequestBody String programId)
	{
		programService.delelteProgram(programId);
		return new ResponseEntity<String>("Succesfully Deleted",HttpStatus.OK);
	}
	
	
	@PostMapping(value="/admin/programs/")
	public ResponseEntity<ProgramDTO>  addprogram(@RequestBody ProgramDTO program)
	{
		ProgramDTO res =programService.addProgram(program);
		return new ResponseEntity<ProgramDTO>(res,HttpStatus.OK);
		
	}

}
