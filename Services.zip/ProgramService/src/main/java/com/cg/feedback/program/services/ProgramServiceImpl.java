package com.cg.feedback.program.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.feedback.program.dao.ProgramDAO;
import com.cg.feedback.program.dto.ProgramDTO;
import com.cg.feedback.program.exceptions.CustomException;
@Service
public class ProgramServiceImpl implements ProgramService {
	
	@Autowired
	ProgramDAO programDao;
	
	@Override
	public List<ProgramDTO> getAllPrograms() {
		return programDao.findAll();
	}

	@Override
	public Optional<ProgramDTO> getProgramById(String programId) {
		if(programDao.existsById(programId))
			return programDao.findById(programId);
		else
			throw new CustomException("Program with ID: "+programId+" not present.");
	}

	@Override
	public boolean delelteProgram(String programId) {
		if(programDao.existsById(programId)) {
			programDao.deleteById(programId);
			return true;
		}
		else
			throw new CustomException("Program with ID: "+programId+" not present.");
	}

	@Override
	public ProgramDTO addProgram(ProgramDTO program) {
		if(!programDao.existsById(program.getProgramId())) {
			return programDao.save(program);
		}
		else
			throw new CustomException("Program with ID: "+program.getProgramId()+" already present.");
	}

}
