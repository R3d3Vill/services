package com.cg.feedback.student.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.feedback.student.dao.StudentDAO;
import com.cg.feedback.student.dto.StudentDTO;
import com.cg.feedback.student.exception.CustomException;

@Service
public class StudnetServiceImpl implements StudentService {
	
	@Autowired
	StudentDAO studentDao;

	@Override
	public List<StudentDTO> getAllStudents() {
		return studentDao.findAll();
	}

	@Override
	public Optional<StudentDTO> getStudentById(String studentId) {
		if(studentDao.existsById(studentId))
			return studentDao.findById(studentId);
		else
			throw new CustomException("Student with id :"+studentId+" not found");
			
	}

	@Override
	public boolean removeStudent(String studentId) {
		if(studentDao.existsById(studentId))
		{
			studentDao.deleteById(studentId);
			return true;
		}
		else
			throw new CustomException("Student with id :"+studentId+" not found");
	}

	@Override
	public StudentDTO addStudent(StudentDTO student) {
		if(!studentDao.existsById(student.getStudentId()))
			return studentDao.save(student);
		else
			throw new CustomException("Student with Id:"+ student.getStudentId()+"already present.");
	}

}
