package com.cg.feedback.student.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cg.feedback.student.dto.StudentDTO;
import com.cg.feedback.student.service.StudentService;


@RestController
public class StudentController {

	@Autowired
	StudentService studentService;
	
	@GetMapping(value="/all/students/")
	public ResponseEntity<List<StudentDTO>> getAllStudents()
	{
		List<StudentDTO> students=studentService.getAllStudents();
		return new ResponseEntity<List<StudentDTO>>(students, HttpStatus.OK);
	}
	
	
	@GetMapping(value="/all/students/{studentId}")
	public ResponseEntity<StudentDTO> getStudentById(@PathVariable("studentId") String studentId)
	{
		StudentDTO student =studentService.getStudentById(studentId).get();
		return new ResponseEntity<StudentDTO>(student,HttpStatus.OK);
	}
	
	
	@DeleteMapping(value="/admin/students/")
	public ResponseEntity<String> delteStudentById(@RequestBody String studentId)
	{
		studentService.removeStudent(studentId);
		return new ResponseEntity<String>("Succesfully Deleted",HttpStatus.OK);
	}
	
	
	@PostMapping(value="/admin/students/")
	public ResponseEntity<StudentDTO>  addStudent(@RequestBody StudentDTO student)
	{
		StudentDTO res =studentService.addStudent(student);
		return new ResponseEntity<StudentDTO>(res,HttpStatus.OK);
		
	}
	
	
}
