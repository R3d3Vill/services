package com.cg.feedback.trainer.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cg.feedback.trainer.dto.TrainerDTO;
import com.cg.feedback.trainer.services.TrainerService;


@RestController
public class TrainerController {
	
	@Autowired
	TrainerService trainerService;
	

	@GetMapping(value="/all/trainers/")
	public ResponseEntity<List<TrainerDTO>> getAlltrainers()
	{
		List<TrainerDTO> trainers=trainerService.getAllTrainers();
		return new ResponseEntity<List<TrainerDTO>>(trainers, HttpStatus.OK);
	}
	
	
	@GetMapping(value="/all/trainers/{trainerId}")
	public ResponseEntity<TrainerDTO> gettrainerById(@PathVariable("trainerId") String trainerId)
	{
		TrainerDTO trainer =trainerService.getTrainerById(trainerId).get();
		return new ResponseEntity<TrainerDTO>(trainer,HttpStatus.OK);
	}
	
	
	@DeleteMapping(value="/admin/trainers/")
	public ResponseEntity<String> deltetrainerById(@RequestBody String trainerId)
	{
		trainerService.removeTrainer(trainerId);
		return new ResponseEntity<String>("Succesfully Deleted",HttpStatus.OK);
	}
	
	
	@PostMapping(value="/admin/trainers/")
	public ResponseEntity<TrainerDTO>  addtrainer(@RequestBody TrainerDTO trainer)
	{
		TrainerDTO res =trainerService.addTrainer(trainer);
		return new ResponseEntity<TrainerDTO>(res,HttpStatus.OK);
		
	}
	
	@PostMapping(value="/admin/tainers/{trainerId}/addSkill/")
	public ResponseEntity<String> addSkill(@PathVariable("trainerId")String trainerId,@RequestBody String skill)
	{
		String response=trainerService.addTrainerSkill(trainerId, skill);
		return new ResponseEntity<String>(response,HttpStatus.OK);
	}
	
	@GetMapping(value="/admin/tainers/{trainerId}/skills/")
	public ResponseEntity<List<String>> getSkills(@PathVariable("trainerId")String trainerId)
	{
		List<String> response=trainerService.getTrainerSkills(trainerId);
		return new ResponseEntity<List<String>>(response,HttpStatus.OK);
	}


}
