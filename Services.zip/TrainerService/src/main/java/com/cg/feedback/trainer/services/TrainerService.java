package com.cg.feedback.trainer.services;

import java.util.List;
import java.util.Optional;
import com.cg.feedback.trainer.dto.TrainerDTO;

public interface TrainerService {
	List<TrainerDTO> getAllTrainers();
	Optional<TrainerDTO> getTrainerById(String trainerId);
	boolean removeTrainer(String trainerId);
	TrainerDTO addTrainer(TrainerDTO trainer);
	String addTrainerSkill(String trainerId,String skill);
	List<String> getTrainerSkills(String trainerId);
}
