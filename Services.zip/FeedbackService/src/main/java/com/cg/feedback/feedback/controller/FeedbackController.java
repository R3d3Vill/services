package com.cg.feedback.feedback.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.cg.feedback.feedback.dto.FeedbackDTO;
import com.cg.feedback.feedback.service.FeedbackService;

@RestController
public class FeedbackController {

	@Autowired
	FeedbackService feedbackService;
	
	@GetMapping(value="/all/feedbacks/{programId}")
	public ResponseEntity<List<FeedbackDTO>> getAllFeedbacksForProgram(@PathVariable("programId")String programId)
	{
		List<FeedbackDTO> feedbacks=feedbackService.viewFeedbackByProgram(programId);
		return new ResponseEntity<List<FeedbackDTO>>(feedbacks,HttpStatus.OK);
	}
	
	@GetMapping(value="/all/feedbacks/{trainerId}")
	public ResponseEntity<List<FeedbackDTO>> getAllFeedbacksForTrainer(@PathVariable("trainerId")String trainerId)
	{
		List<FeedbackDTO> feedbacks=feedbackService.viewFeedbackByTrainer(trainerId);
		return new ResponseEntity<List<FeedbackDTO>>(feedbacks,HttpStatus.OK);
	}
	
	@GetMapping(value="/student/available_feedbacks/{studentId}")
	public ResponseEntity<List<String>> getAvailableFeedbacks(@PathVariable("studentId") String studentId)
	{
		List<String> available=feedbackService.feedbacksGivenForStudnet(studentId);
		return new ResponseEntity<List<String>>(available,HttpStatus.OK);
	}
	
	
}
